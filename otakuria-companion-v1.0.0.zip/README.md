# Otakuria Companion - Extensión de Navegador

Esta extensión actúa como un puente de red entre el sitio web de Otakuria y tu navegador:
1. **Conectividad directa:** Realiza peticiones a fuentes de lectura directamente desde tu navegador para mayor velocidad y privacidad.
2. **Sincronización de sesión:** Permite que Otakuria sincronice el contenido web directamente con tu navegador sin intermediarios.

---

## 🚀 Cómo Instalar en Chrome, Brave, Edge o Opera (30 segundos)

1. Abre tu navegador y ve a la página de extensiones:
   - En **Google Chrome / Brave:** `chrome://extensions/`
   - En **Microsoft Edge:** `edge://extensions/`
   - En **Opera:** `opera://extensions/`
2. Activa el interruptor **"Modo de desarrollador"** (Developer mode) en la esquina superior derecha.
3. Haz clic en el botón **"Cargar descomprimida"** (Load unpacked).
4. Selecciona esta carpeta:
   `Otakuria/extension`
5. ¡Listo! Verás la extensión **Otakuria Companion** instalada y activa.
6. Ahora recarga la web de Otakuria. Otakuria la detectará automáticamente.
